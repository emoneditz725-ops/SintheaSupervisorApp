package com.sinthea.supervisor.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sinthea.supervisor.data.Shades
import com.sinthea.supervisor.ui.components.GradientBackground
import com.sinthea.supervisor.ui.theme.TextPrimary
import com.sinthea.supervisor.ui.theme.TextSecondary
import com.sinthea.supervisor.ui.components.ShadeCard
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DashboardScreen(
    supervisorName: String,
    onShadeClick: (id: String, name: String) -> Unit,
    onHistoryClick: () -> Unit,
    onLogout: () -> Unit
) {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(1000)
        }
    }
    val dateFmt = remember { SimpleDateFormat("dd MMM yyyy (EEEE)", Locale.getDefault()) }
    val timeFmt = remember { SimpleDateFormat("hh:mm:ss a", Locale.getDefault()) }

    GradientBackground {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("M/S SINTHEA ENTERPRISE", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("স্বাগতম, $supervisorName", color = TextSecondary, fontSize = 13.sp)
                }
                Row {
                    IconButton(onClick = onHistoryClick) {
                        Icon(Icons.Filled.History, contentDescription = "History", tint = TextPrimary)
                    }
                    IconButton(onClick = onLogout) {
                        Icon(Icons.Filled.Logout, contentDescription = "Logout", tint = TextPrimary)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Text(dateFmt.format(now), color = TextPrimary, fontSize = 14.sp)
            Text(timeFmt.format(now), color = TextSecondary, fontSize = 13.sp)

            Spacer(Modifier.height(20.dp))
            Text("শেড নির্বাচন করুন", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Spacer(Modifier.height(10.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(Shades.list) { (id, name) ->
                    ShadeCard(title = name, subtitle = "রিপোর্ট তৈরি/আপডেট করুন") {
                        onShadeClick(id, name)
                    }
                }
            }
        }
    }
}
