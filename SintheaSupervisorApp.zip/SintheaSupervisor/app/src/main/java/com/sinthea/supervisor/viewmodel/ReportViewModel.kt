package com.sinthea.supervisor.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sinthea.supervisor.data.FirestoreRepository
import com.sinthea.supervisor.data.Report
import kotlinx.coroutines.launch

class ReportViewModel : ViewModel() {
    private val repo = FirestoreRepository()

    val isLoading = mutableStateOf(false)
    val saveSuccess = mutableStateOf<String?>(null)
    val errorMessage = mutableStateOf<String?>(null)
    val existingReport = mutableStateOf<Report?>(null)

    val loadContainer = mutableStateOf("")
    val unloadCoverVan = mutableStateOf("")
    val partContainer = mutableStateOf("")
    val balanceCoverVan = mutableStateOf("")

    val myReports = mutableStateOf<List<Report>>(emptyList())

    fun loadTodayReport(shadeId: String) {
        viewModelScope.launch {
            val report = repo.getReport(shadeId, repo.today())
            existingReport.value = report
            report?.let {
                loadContainer.value = it.loadContainer.toString()
                unloadCoverVan.value = it.unloadCoverVan.toString()
                partContainer.value = it.partContainer.toString()
                balanceCoverVan.value = it.balanceCoverVan.toString()
            }
        }
    }

    fun clearForm() {
        loadContainer.value = ""
        unloadCoverVan.value = ""
        partContainer.value = ""
        balanceCoverVan.value = ""
        errorMessage.value = null
    }

    private fun numOrNull(s: String): Double? = s.trim().toDoubleOrNull()

    fun saveReport(shadeId: String, shadeName: String, supervisorName: String, supervisorEmail: String) {
        val load = numOrNull(loadContainer.value)
        val unload = numOrNull(unloadCoverVan.value)
        val part = numOrNull(partContainer.value)
        val balance = numOrNull(balanceCoverVan.value)

        if (load == null || unload == null || part == null || balance == null) {
            errorMessage.value = "সব ফিল্ডে সঠিক সংখ্যা দিন"
            return
        }

        val report = Report(
            shadeId = shadeId,
            shadeName = shadeName,
            date = repo.today(),
            supervisorName = supervisorName,
            supervisorEmail = supervisorEmail,
            loadContainer = load,
            unloadCoverVan = unload,
            partContainer = part,
            balanceCoverVan = balance
        )

        isLoading.value = true
        errorMessage.value = null
        viewModelScope.launch {
            val result = repo.saveOrUpdateReport(report)
            isLoading.value = false
            result.onSuccess {
                saveSuccess.value = "রিপোর্ট সফলভাবে সংরক্ষণ হয়েছে ✅"
                existingReport.value = report
            }.onFailure {
                errorMessage.value = "সংরক্ষণ ব্যর্থ: ${it.message}"
            }
        }
    }

    fun loadMyReports() {
        viewModelScope.launch {
            myReports.value = repo.getMyReports()
        }
    }

    fun loadMyReportsByDate(date: String) {
        viewModelScope.launch {
            myReports.value = repo.getMyReportsByDate(date)
        }
    }

    fun isEditable(report: Report) = repo.isEditable(report)
    fun currentSupervisorName() = repo.currentUserName()
    fun currentSupervisorEmail() = repo.currentUserEmail() ?: ""
}
