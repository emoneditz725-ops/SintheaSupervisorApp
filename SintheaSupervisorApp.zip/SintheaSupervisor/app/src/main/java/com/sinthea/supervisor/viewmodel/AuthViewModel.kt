package com.sinthea.supervisor.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sinthea.supervisor.data.FirestoreRepository
import kotlinx.coroutines.launch

class AuthViewModel : ViewModel() {
    private val repo = FirestoreRepository()

    val isLoading = mutableStateOf(false)
    val errorMessage = mutableStateOf<String?>(null)
    val loggedIn = mutableStateOf(repo.isLoggedIn())

    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            errorMessage.value = "ইমেইল ও পাসওয়ার্ড দিন"
            return
        }
        isLoading.value = true
        errorMessage.value = null
        viewModelScope.launch {
            val result = repo.login(email.trim(), password)
            isLoading.value = false
            result.onSuccess {
                loggedIn.value = true
            }.onFailure {
                errorMessage.value = "লগইন ব্যর্থ: ${it.message}"
            }
        }
    }

    fun logout() {
        repo.logout()
        loggedIn.value = false
    }
}
