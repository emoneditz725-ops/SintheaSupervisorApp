package com.sinthea.supervisor.data

/**
 * One document per (shadeId + date) in Firestore collection "reports".
 * Document ID convention: "<shadeId>_<yyyy-MM-dd>"
 * This exact shape is shared with the Boss app.
 */
data class Report(
    var id: String = "",
    var shadeId: String = "",          // e.g. "SHADE_5"
    var shadeName: String = "",        // e.g. "SHADE - 5 TABLE"
    var date: String = "",             // yyyy-MM-dd
    var time: String = "",             // HH:mm:ss (last update time)
    var supervisorName: String = "",
    var supervisorEmail: String = "",
    var loadContainer: Double = 0.0,
    var unloadCoverVan: Double = 0.0,
    var partContainer: Double = 0.0,
    var balanceCoverVan: Double = 0.0,
    var status: String = "PENDING",    // PENDING | SUBMITTED | APPROVED | REJECTED
    var bossNote: String = "",
    var updatedAtMillis: Long = 0L
)

/** Fixed list of shades shown as dashboard cards in both apps. */
object Shades {
    val list = listOf(
        "SHADE_5" to "SHADE - 5 TABLE",
        "SHADE_6" to "SHADE - 6 TABLE",
        "SHADE_8" to "SHADE - 8 TABLE",
        "SHADE_10" to "SHADE - 10 TABLE",
        "SHADE_1" to "SHADE - 1 TABLE",
        "SHADE_2" to "SHADE - 2 TABLE"
    )
}
