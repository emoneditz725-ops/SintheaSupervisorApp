package com.sinthea.supervisor

import android.app.Application
import com.google.firebase.FirebaseApp

class SintheaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
    }
}
