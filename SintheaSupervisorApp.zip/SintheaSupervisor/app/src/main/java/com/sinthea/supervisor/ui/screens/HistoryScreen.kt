package com.sinthea.supervisor.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sinthea.supervisor.data.Report
import com.sinthea.supervisor.ui.components.GlassCard
import com.sinthea.supervisor.ui.components.GradientBackground
import com.sinthea.supervisor.ui.theme.TextPrimary
import com.sinthea.supervisor.ui.theme.TextSecondary
import com.sinthea.supervisor.viewmodel.ReportViewModel

@Composable
fun HistoryScreen(viewModel: ReportViewModel, onBack: () -> Unit, onEdit: (Report) -> Unit) {
    var searchDate by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { viewModel.loadMyReports() }

    GradientBackground {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = null, tint = TextPrimary)
                }
                Text("আমার রিপোর্ট হিস্ট্রি", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }

            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = searchDate,
                    onValueChange = { searchDate = it },
                    label = { Text("Search by date (yyyy-MM-dd)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    if (searchDate.isBlank()) viewModel.loadMyReports()
                    else viewModel.loadMyReportsByDate(searchDate.trim())
                }) { Text("Search") }
            }

            Spacer(Modifier.height(16.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(viewModel.myReports.value) { report ->
                    val editable = viewModel.isEditable(report)
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(report.shadeName, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                                Text("${report.date}  •  ${report.time}", color = TextSecondary, fontSize = 12.sp)
                            }
                            if (editable) {
                                TextButton(onClick = { onEdit(report) }) { Text("Edit") }
                            } else {
                                Text("Read-only", color = TextSecondary, fontSize = 12.sp)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Load: ${report.loadContainer}  |  Unload CV: ${report.unloadCoverVan}  |  " +
                                "Part: ${report.partContainer}  |  Balance CV: ${report.balanceCoverVan}",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}
