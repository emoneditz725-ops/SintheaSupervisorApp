package com.sinthea.supervisor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.sinthea.supervisor.ui.screens.*
import com.sinthea.supervisor.ui.theme.SintheaTheme
import com.sinthea.supervisor.viewmodel.AuthViewModel
import com.sinthea.supervisor.viewmodel.ReportViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SintheaTheme {
                AppNav()
            }
        }
    }
}

@Composable
fun AppNav() {
    val navController = rememberNavController()
    val authViewModel: AuthViewModel = viewModel()
    val reportViewModel: ReportViewModel = viewModel()

    NavHost(navController = navController, startDestination = "splash") {
        composable("splash") {
            SplashScreen {
                val dest = if (authViewModel.loggedIn.value) "dashboard" else "login"
                navController.navigate(dest) { popUpTo("splash") { inclusive = true } }
            }
        }
        composable("login") {
            LoginScreen(authViewModel) {
                navController.navigate("dashboard") { popUpTo("login") { inclusive = true } }
            }
        }
        composable("dashboard") {
            DashboardScreen(
                supervisorName = reportViewModel.currentSupervisorName(),
                onShadeClick = { id, name -> navController.navigate("report/$id/$name") },
                onHistoryClick = { navController.navigate("history") },
                onLogout = {
                    authViewModel.logout()
                    navController.navigate("login") { popUpTo("dashboard") { inclusive = true } }
                }
            )
        }
        composable(
            "report/{shadeId}/{shadeName}",
            arguments = listOf(
                navArgument("shadeId") { type = NavType.StringType },
                navArgument("shadeName") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val shadeId = backStackEntry.arguments?.getString("shadeId") ?: ""
            val shadeName = backStackEntry.arguments?.getString("shadeName") ?: ""
            ReportScreen(
                shadeId = shadeId,
                shadeName = shadeName,
                supervisorName = reportViewModel.currentSupervisorName(),
                supervisorEmail = reportViewModel.currentSupervisorEmail(),
                viewModel = reportViewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable("history") {
            HistoryScreen(
                viewModel = reportViewModel,
                onBack = { navController.popBackStack() },
                onEdit = { report ->
                    navController.navigate("report/${report.shadeId}/${report.shadeName}")
                }
            )
        }
    }
}
