package com.sinthea.supervisor.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sinthea.supervisor.ui.components.GlassCard
import com.sinthea.supervisor.ui.components.GradientBackground
import com.sinthea.supervisor.ui.theme.ErrorRed
import com.sinthea.supervisor.ui.theme.SuccessGreen
import com.sinthea.supervisor.ui.theme.TextPrimary
import com.sinthea.supervisor.viewmodel.ReportViewModel

@Composable
fun ReportScreen(
    shadeId: String,
    shadeName: String,
    supervisorName: String,
    supervisorEmail: String,
    viewModel: ReportViewModel,
    onBack: () -> Unit
) {
    LaunchedEffect(shadeId) {
        viewModel.clearForm()
        viewModel.loadTodayReport(shadeId)
    }

    val isUpdate = viewModel.existingReport.value != null

    GradientBackground {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = null, tint = TextPrimary)
                }
                Text(shadeName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }

            Spacer(Modifier.height(16.dp))

            GlassCard(modifier = Modifier.fillMaxWidth()) {
                NumberField("Load Container", viewModel.loadContainer.value) { viewModel.loadContainer.value = it }
                Spacer(Modifier.height(12.dp))
                NumberField("Unload Cover Van", viewModel.unloadCoverVan.value) { viewModel.unloadCoverVan.value = it }
                Spacer(Modifier.height(12.dp))
                NumberField("Part Container", viewModel.partContainer.value) { viewModel.partContainer.value = it }
                Spacer(Modifier.height(12.dp))
                NumberField("Balance Cover Van", viewModel.balanceCoverVan.value) { viewModel.balanceCoverVan.value = it }

                viewModel.errorMessage.value?.let {
                    Spacer(Modifier.height(10.dp))
                    Text(it, color = ErrorRed, fontSize = 13.sp)
                }
                viewModel.saveSuccess.value?.let {
                    Spacer(Modifier.height(10.dp))
                    Text(it, color = SuccessGreen, fontSize = 13.sp)
                }

                Spacer(Modifier.height(20.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            viewModel.saveReport(shadeId, shadeName, supervisorName, supervisorEmail)
                        },
                        enabled = !viewModel.isLoading.value,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (isUpdate) "Update Report" else "Save Report")
                    }
                    OutlinedButton(
                        onClick = { viewModel.clearForm() },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Clear Form")
                    }
                }
            }
        }
    }
}

@Composable
private fun NumberField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { new -> if (new.all { it.isDigit() || it == '.' }) onChange(new) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth()
    )
}
