package com.sinthea.supervisor.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warehouse
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sinthea.supervisor.ui.components.GradientBackground
import com.sinthea.supervisor.ui.theme.ElectricBlue
import com.sinthea.supervisor.ui.theme.TextPrimary
import com.sinthea.supervisor.ui.theme.TextSecondary
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val alpha = remember { Animatable(0f) }
    val scale = remember { Animatable(0.8f) }

    LaunchedEffect(Unit) {
        alpha.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
        scale.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
        delay(1200)
        onFinished()
    }

    GradientBackground {
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .graphicsLayer { this.alpha = alpha.value; scaleX = scale.value; scaleY = scale.value },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Filled.Warehouse,
                contentDescription = null,
                tint = ElectricBlue,
                modifier = Modifier.size(72.dp)
            )
            Spacer(Modifier.height(16.dp))
            Text(
                "M/S SINTHEA ENTERPRISE",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp
            )
            Spacer(Modifier.height(6.dp))
            Text("Supervisor Reporting System", color = TextSecondary, fontSize = 13.sp)
        }
    }
}
