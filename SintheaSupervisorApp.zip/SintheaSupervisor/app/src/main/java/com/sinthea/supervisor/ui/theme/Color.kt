package com.sinthea.supervisor.ui.theme

import androidx.compose.ui.graphics.Color

val DeepNavy = Color(0xFF0B0F2B)
val DeepPurple = Color(0xFF1A1035)
val ElectricBlue = Color(0xFF3B82F6)
val VividPurple = Color(0xFF8B5CF6)
val GlassWhite = Color(0x1AFFFFFF)
val GlassBorder = Color(0x33FFFFFF)
val TextPrimary = Color(0xFFF5F6FA)
val TextSecondary = Color(0xFFA0A6C0)
val SuccessGreen = Color(0xFF22C55E)
val WarningYellow = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)

val GradientColors = listOf(DeepNavy, DeepPurple, ElectricBlue.copy(alpha = 0.25f))
