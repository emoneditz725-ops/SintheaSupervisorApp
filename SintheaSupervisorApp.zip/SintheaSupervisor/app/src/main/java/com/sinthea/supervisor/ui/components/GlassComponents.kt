package com.sinthea.supervisor.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.runtime.remember
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sinthea.supervisor.ui.theme.*

/** Full-screen navy -> purple -> blue gradient background. */
@Composable
fun GradientBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(GradientColors)),
        content = content
    )
}

/** Frosted-glass style card used everywhere in the app. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val base = modifier
        .clip(RoundedCornerShape(20.dp))
        .background(GlassWhite)
        .border(1.dp, GlassBorder, RoundedCornerShape(20.dp))
        .padding(18.dp)

    Column(
        modifier = if (onClick != null) base.then(
            Modifier.clip(RoundedCornerShape(20.dp))
        ) else base
    ) {
        content()
    }
}

@Composable
fun ShadeCard(title: String, subtitle: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(ElectricBlue.copy(alpha = 0.35f), VividPurple.copy(alpha = 0.35f))))
            .border(1.dp, GlassBorder, RoundedCornerShape(20.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = rememberRipple(color = ElectricBlue),
                onClick = onClick
            )
            .padding(20.dp)
    ) {
        Column {
            Text(title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = TextSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
fun StatusDot(status: String) {
    val (emoji, _) = when (status) {
        "SUBMITTED", "APPROVED" -> "🟢" to SuccessGreen
        "PENDING" -> "🟡" to WarningYellow
        else -> "🔴" to ErrorRed
    }
    Text(emoji, fontSize = 14.sp)
}
