package com.sinthea.supervisor.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.*

class FirestoreRepository {

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()
    private val reportsCol = db.collection("reports")

    // ---------- Auth ----------

    suspend fun login(email: String, password: String): Result<String> {
        return try {
            val result = auth.signInWithEmailAndPassword(email, password).await()
            val name = result.user?.displayName ?: email.substringBefore("@")
            Result.success(name)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun logout() = auth.signOut()

    fun currentUserEmail(): String? = auth.currentUser?.email
    fun currentUserName(): String = auth.currentUser?.displayName
        ?: auth.currentUser?.email?.substringBefore("@") ?: "Supervisor"
    fun isLoggedIn(): Boolean = auth.currentUser != null

    // ---------- Reports ----------

    private fun todayDate(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    private fun nowTime(): String =
        SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

    fun docIdFor(shadeId: String, date: String) = "${shadeId}_$date"

    suspend fun saveOrUpdateReport(report: Report): Result<Unit> {
        return try {
            val date = report.date.ifBlank { todayDate() }
            val docId = docIdFor(report.shadeId, date)
            report.date = date
            report.time = nowTime()
            report.status = "SUBMITTED"
            report.updatedAtMillis = System.currentTimeMillis()
            reportsCol.document(docId).set(report).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getReport(shadeId: String, date: String): Report? {
        return try {
            val snap = reportsCol.document(docIdFor(shadeId, date)).get().await()
            snap.toObject(Report::class.java)
        } catch (e: Exception) {
            null
        }
    }

    /** Reports submitted by the currently logged-in supervisor, newest first. */
    suspend fun getMyReports(): List<Report> {
        val email = currentUserEmail() ?: return emptyList()
        return try {
            reportsCol.whereEqualTo("supervisorEmail", email)
                .get().await()
                .toObjects(Report::class.java)
                .sortedByDescending { it.updatedAtMillis }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getMyReportsByDate(date: String): List<Report> {
        val email = currentUserEmail() ?: return emptyList()
        return try {
            reportsCol.whereEqualTo("supervisorEmail", email)
                .whereEqualTo("date", date)
                .get().await()
                .toObjects(Report::class.java)
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun isEditable(report: Report): Boolean = report.date == todayDate()
    fun today(): String = todayDate()
}
