# M/S SINTHEA ENTERPRISE — Supervisor App

Kotlin + Jetpack Compose (Material 3) + Firebase Auth + Firestore.

## Setup (Android Studio)

1. Open this folder in **Android Studio (Hedgehog or newer)**.
2. Let it generate the Gradle wrapper if prompted, or run `gradle wrapper` once from a terminal with Gradle installed.
3. Go to **Firebase Console** → create a project (or use an existing one — must be the SAME project used for the Boss app so both apps share one Firestore database).
4. Add an Android app with package name `com.sinthea.supervisor`.
5. Download `google-services.json` and place it in `app/google-services.json`.
6. Enable **Email/Password** sign-in in Firebase Authentication, and manually create supervisor accounts (Firebase Console → Authentication → Add user). Only accounts you create can log in — there is no public sign-up screen, by design.
7. Enable **Cloud Firestore** (production mode). Recommended security rule starting point:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /reports/{reportId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null
        && request.resource.data.supervisorEmail == request.auth.token.email;
    }
  }
}
```

8. Build & run on a device/emulator.

## What's included
- Splash screen with fade/scale animation
- Email/password login (Firebase Auth)
- Dashboard with live date/time and 6 shade cards (5, 6, 8, 10, 1, 2 table)
- Report form (Load Container, Unload Cover Van, Part Container, Balance Cover Van — numeric only)
- Save / Update / Clear buttons, synced to Firestore collection `reports`
- History screen: search by date, only shows the logged-in supervisor's own reports, today's report is editable, older ones are read-only
- Dark premium theme (navy/purple/blue gradient, glassmorphism cards)

## Firestore document shape (`reports/{shadeId}_{yyyy-MM-dd}`)
```
shadeId, shadeName, date, time, supervisorName, supervisorEmail,
loadContainer, unloadCoverVan, partContainer, balanceCoverVan,
status, bossNote, updatedAtMillis
```
This exact shape is read by the Boss app — do not rename fields without updating both apps.

## Not yet wired up (documented for next iteration)
- Lottie animation file (add a `.json` file under `res/raw` and reference it in `SplashScreen.kt`)
- Push notifications to the Boss app on submit (needs a small Cloud Function — see Boss app README)
- True offline queue UI (Firestore's built-in offline cache is enabled by default, so data queues and syncs automatically, but there's no visible "pending sync" indicator yet)
